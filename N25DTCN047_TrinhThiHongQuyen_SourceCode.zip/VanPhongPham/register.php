<?php require 'includes/init.php';
if (current_user()) go();
$pageTitle = 'Đăng ký';
$errors = [];
$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $pw = (string)($_POST['password'] ?? '');
    if (mb_strlen($name) < 2) $errors[] = 'Họ tên phải có ít nhất 2 ký tự.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email không hợp lệ.';
    if (strlen($pw) < 8) $errors[] = 'Mật khẩu cần ít nhất 8 ký tự.';
    if ($pw !== ($_POST['confirm'] ?? '')) $errors[] = 'Hai mật khẩu không khớp.';
    $q = $pdo->prepare('SELECT id FROM users WHERE email=?');
    $q->execute([$email]);
    if ($q->fetch()) $errors[] = 'Email đã được sử dụng.';
    if (!$errors) {
        $q = $pdo->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)');
        $q->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT), 'customer']);
        flash('Đăng ký thành công. Vui lòng đăng nhập.');
        go('login.php');
    }
}
require 'includes/header.php'; ?><main class="container section narrow">
    <h1>Đăng ký thành viên</h1><?php foreach ($errors as $err): ?><div class="error"><?= e($err) ?></div><?php endforeach; ?><form class="form-card" method="post" data-register><?= csrf_input() ?><label>Họ tên<input name="name" required minlength="2" value="<?= e($name) ?>"></label><label>Email<input name="email" type="email" required value="<?= e($email) ?>"></label><label>Mật khẩu<input name="password" type="password" minlength="8" required></label><label>Nhập lại mật khẩu<input name="confirm" type="password" minlength="8" required></label><button class="btn">Tạo tài khoản</button></form>
    <p>Đã có tài khoản? <a href="<?= e(url('login.php')) ?>">Đăng nhập</a></p>
</main><?php require 'includes/footer.php'; ?>