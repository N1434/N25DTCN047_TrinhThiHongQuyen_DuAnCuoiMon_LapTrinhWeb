<?php require 'includes/init.php';
post_only();
$id = (int)($_POST['id'] ?? 0);
$qty = max(1, min(99, (int)($_POST['qty'] ?? 1)));
$p = get_product($pdo, $id);
if (!$p || $p['stock'] < 1) {
    flash('Sản phẩm không có sẵn.', 'bad');
    go();
}
$_SESSION['cart'][$id] = min($p['stock'], ($_SESSION['cart'][$id] ?? 0) + $qty);
flash('Đã thêm vào giỏ hàng.');
go('cart.php');
