<?php
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function url(string $path = ''): string
{
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function go(string $path = 'index.php'): void
{
    header('Location: ' . url($path));
    exit;
}
function money($amount): string
{
    return number_format((float)$amount, 0, ',', '.') . ' ₫';
}
function csrf(): string
{
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
}
function csrf_input(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf()) . '">';
}
function verify_csrf(): void
{
    if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        exit('CSRF token không hợp lệ.');
    }
}
function flash(string $message, string $kind = 'ok'): void
{
    $_SESSION['flash'] = ['message' => $message, 'kind' => $kind];
}
function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}
function safe_next(string $next): string
{
    if ($next === '' || str_starts_with($next, '//') || preg_match('~^[a-z]+:~i', $next) || str_contains($next, '\\') || str_contains($next, "\n")) return 'index.php';
    return ltrim($next, '/');
}
function require_login(): void
{
    if (!current_user()) {
        $_SESSION['after_login'] = safe_next((string)($_SERVER['REQUEST_URI'] ?? 'index.php'));
        go('login.php');
    }
}
function require_admin(): void
{
    if (!current_user() || current_user()['role'] !== 'admin') {
        http_response_code(403);
        $pageTitle = '403 - Không có quyền';
        require __DIR__ . '/header.php';
        echo '<main class="container section"><div class="empty"><h1>403 · Truy cập bị từ chối</h1><p>Bạn không có quyền xem khu vực quản trị.</p><a class="btn" href="' . e(url()) . '">Về trang chủ</a></div></main>';
        require __DIR__ . '/footer.php';
        exit;
    }
}
function post_only(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Method not allowed');
    }
    verify_csrf();
}
function get_product(PDO $db, int $id): ?array
{
    $s = $db->prepare('SELECT p.*, c.name category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?');
    $s->execute([$id]);
    return $s->fetch() ?: null;
}
function cart_lines(PDO $db): array
{
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    $ids = array_keys($cart);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $q = $db->prepare("SELECT * FROM products WHERE id IN ($in)");
    $q->execute($ids);
    $rows = [];
    foreach ($q as $p) {
        $p['qty'] = max(1, min(99, (int)$cart[$p['id']]));
        $p['subtotal'] = $p['price'] * $p['qty'];
        $rows[] = $p;
    }
    return $rows;
}
function product_card(array $p): void
{ ?>
    <article class="product-card"><a href="<?= e(url('product.php?id=' . $p['id'])) ?>"><img src="<?= e(url($p['image'])) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
            <div class="product-body"><span class="muted"><?= e($p['category_name'] ?? 'Văn phòng phẩm') ?></span>
                <h3><?= e($p['name']) ?></h3><strong class="price"><?= money($p['price']) ?></strong><small>Còn <?= (int)$p['stock'] ?> sản phẩm</small>
            </div>
        </a>
        <form action="<?= e(url('cart-add.php')) ?>" method="post"><?= csrf_input() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-small" <?= $p['stock'] < 1 ? 'disabled' : '' ?>>Thêm vào giỏ</button></form>
    </article>
<?php }
function status_label(string $s): string
{
    return ['pending' => 'Chờ xử lý', 'shipping' => 'Đang giao', 'completed' => 'Hoàn tất', 'cancelled' => 'Đã hủy'][$s] ?? $s;
}
function valid_status(string $s): bool
{
    return in_array($s, ['pending', 'shipping', 'completed', 'cancelled'], true);
}
function delete_upload(string $name): void
{
    if (str_starts_with($name, 'uploads/') && !str_contains($name, '..')) {
        $p = __DIR__ . '/../' . $name;
        if (is_file($p)) unlink($p);
    }
}
function image_upload(string $key): ?string
{
    if (empty($_FILES[$key]['name'])) return null;
    $f = $_FILES[$key];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > MAX_UPLOAD_BYTES) throw new RuntimeException('Ảnh không hợp lệ hoặc vượt 2MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($extensions[$mime]) || !getimagesize($f['tmp_name'])) throw new RuntimeException('Chỉ chấp nhận ảnh JPG, PNG, WebP.');
    $target = 'uploads/' . bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($f['tmp_name'], __DIR__ . '/../' . $target)) throw new RuntimeException('Không lưu được ảnh.');
    return $target;
}
