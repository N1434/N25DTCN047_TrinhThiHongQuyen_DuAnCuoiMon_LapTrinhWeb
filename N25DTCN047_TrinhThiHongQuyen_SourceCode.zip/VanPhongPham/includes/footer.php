<footer class="site-footer">
    <div class="container footer-inner">
        <div><strong><?= e(STORE_NAME) ?></strong>
            <p>Văn phòng phẩm đẹp cho những ngày học tập đầy cảm hứng.</p>
        </div>
        <div>Họ tên: <?= e(STUDENT_NAME) ?><br>Mã số sinh viên: <?= e(STUDENT_ID) ?></div>
    </div>
</footer>
</body>

</html>