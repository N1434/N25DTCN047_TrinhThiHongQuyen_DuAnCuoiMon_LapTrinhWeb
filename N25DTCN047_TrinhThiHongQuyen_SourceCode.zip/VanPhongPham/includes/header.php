<?php $pageTitle = $pageTitle ?? 'Văn phòng phẩm';
$active = basename(parse_url($_SERVER['SCRIPT_NAME'], PHP_URL_PATH)); ?>
<!doctype html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?> | <?= e(STORE_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(url('css/style.css')) ?>">
    <script defer src="<?= e(url('js/main.js')) ?>"></script>
</head>

<body>
    <header class="site-header">
        <div class="container topbar"><a class="brand" href="<?= e(url()) ?>"><span class="portrait"><img src="<?= e(url('images/portrait.png
')) ?>" alt="Ảnh chân dung chủ cửa hàng" onerror="this.style.display='none';this.parentElement.textContent='ẢNH';"></span><span><b><?= e(STORE_NAME) ?></b><small>Góc học tập · Cảm hứng mỗi ngày</small></span></a><span class="header-note">✦ Chọn điều nhỏ, tạo cảm hứng lớn</span></div>
        <nav class="main-nav">
            <div class="container nav-inner"><a class="<?= $active === 'index.php' ? 'active' : '' ?>" href="<?= e(url('index.php')) ?>">Sản phẩm</a><a class="<?= $active === 'about.php' ? 'active' : '' ?>" href="<?= e(url('about.php')) ?>">Giới thiệu</a><a class="<?= $active === 'contact.php' ? 'active' : '' ?>" href="<?= e(url('contact.php')) ?>">Liên hệ</a><a class="<?= $active === 'cart.php' ? 'active' : '' ?>" href="<?= e(url('cart.php')) ?>">Giỏ hàng (<?= array_sum($_SESSION['cart'] ?? []) ?>)</a><?php if (current_user()): ?><a href="<?= e(url('orders.php')) ?>">Đơn hàng</a><a href="<?= e(url('profile.php')) ?>"><?= e(current_user()['name']) ?></a><?php if (current_user()['role'] === 'admin'): ?><a href="<?= e(url('admin/index.php')) ?>">Quản trị</a><?php endif; ?><form method="post" action="<?= e(url('logout.php')) ?>" class="inline-form"><?= csrf_input() ?><button class="nav-button">Đăng xuất</button></form><?php else: ?><a class="<?= $active === 'login.php' ? 'active' : '' ?>" href="<?= e(url('login.php')) ?>">Đăng nhập</a><a href="<?= e(url('register.php')) ?>">Đăng ký</a><?php endif; ?></div>
        </nav>
    </header>
    <?php if (!empty($_SESSION['flash'])): $f = $_SESSION['flash'];
        unset($_SESSION['flash']); ?><div class="container">
            <div class="alert <?= e($f['kind']) ?>"><?= e($f['message']) ?></div>
        </div><?php endif; ?>