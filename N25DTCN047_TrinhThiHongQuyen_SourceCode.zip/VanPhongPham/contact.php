<?php require 'includes/init.php';
$pageTitle = 'Liên hệ';
$errors = [];
$name = trim((string)($_POST['name'] ?? (current_user()['name'] ?? '')));
$email = trim((string)($_POST['email'] ?? ''));
$message = trim((string)($_POST['message'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (mb_strlen($name) < 2) $errors[] = 'Họ tên quá ngắn.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email không hợp lệ.';
    if (mb_strlen($message) < 10) $errors[] = 'Nội dung phải có ít nhất 10 ký tự.';
    if (!$errors) {
        $s = $pdo->prepare('INSERT INTO contacts(name,email,message,user_id) VALUES(?,?,?,?)');
        $s->execute([$name, $email, $message, current_user()['id'] ?? null]);
        flash('Cảm ơn bạn! Tin nhắn đã được lưu.');
        go('contact.php');
    }
}
require 'includes/header.php'; ?><main class="container section narrow"><span class="eyebrow">KẾT NỐI VỚI CHÚNG MÌNH</span>
    <h1>Liên hệ</h1>
    <p class="muted">Bạn có thắc mắc hoặc góp ý? Gửi lời nhắn ngay nhé.</p><?php foreach ($errors as $err): ?><div class="error"><?= e($err) ?></div><?php endforeach; ?><form class="form-card" method="post" data-contact><?= csrf_input() ?><label>Họ tên<input required name="name" value="<?= e($name) ?>"></label><label>Email<input type="email" name="email" value="<?= e($email) ?>" required></label><label>Nội dung<textarea name="message" minlength="10" required rows="6"><?= e($message) ?></textarea></label><button class="btn">Gửi tin nhắn</button></form>
</main><?php require 'includes/footer.php'; ?>