<?php require 'includes/init.php';
post_only();
unset($_SESSION['user'], $_SESSION['after_login']);
session_regenerate_id(true);
flash('Đã đăng xuất.');
go();
