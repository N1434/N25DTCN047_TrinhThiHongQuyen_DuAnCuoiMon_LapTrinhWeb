<?php require 'includes/init.php';
require_login();
$q = $pdo->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC');
$q->execute([current_user()['id']]);
$pageTitle = 'Lịch sử đơn hàng';
require 'includes/header.php'; ?><main class="container section">
    <h1>Đơn hàng của tôi</h1>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Ngày đặt</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Chi tiết</th>
                </tr>
            </thead>
            <tbody><?php foreach ($q as $o): ?><tr>
                        <td>#<?= $o['id'] ?></td>
                        <td><?= e($o['created_at']) ?></td>
                        <td><?= money($o['total']) ?></td>
                        <td><span class="pill"><?= e(status_label($o['status'])) ?></span></td>
                        <td><a href="<?= e(url('order-detail.php?id=' . $o['id'])) ?>">Xem đơn →</a></td>
                    </tr><?php endforeach; ?></tbody>
        </table>
    </div>
</main><?php require 'includes/footer.php'; ?>