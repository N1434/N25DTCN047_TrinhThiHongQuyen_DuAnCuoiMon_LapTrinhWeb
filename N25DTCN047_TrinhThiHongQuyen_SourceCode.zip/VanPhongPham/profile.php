<?php require 'includes/init.php';
require_login();
$q = $pdo->prepare('SELECT * FROM users WHERE id=?');
$q->execute([current_user()['id']]);
$u = $q->fetch();
$name = trim((string)($_POST['name'] ?? $u['name']));
$phone = trim((string)($_POST['phone'] ?? $u['phone']));
$address = trim((string)($_POST['address'] ?? $u['address']));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (mb_strlen($name) < 2 || ($phone !== '' && !preg_match('/^[0-9+ .-]{9,16}$/', $phone))) $error = 'Thông tin không hợp lệ.';
    else {
        $q = $pdo->prepare('UPDATE users SET name=?,phone=?,address=? WHERE id=?');
        $q->execute([$name, $phone, $address, $u['id']]);
        $_SESSION['user']['name'] = $name;
        flash('Đã cập nhật hồ sơ.');
        go('profile.php');
    }
}
$pageTitle = 'Tài khoản';
require 'includes/header.php'; ?><main class="container section narrow">
    <h1>Thông tin tài khoản</h1><?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?><form class="form-card" method="post"><?= csrf_input() ?><label>Họ tên<input name="name" required value="<?= e($name) ?>"></label><label>Email<input value="<?= e($u['email']) ?>" disabled></label><label>Số điện thoại<input name="phone" value="<?= e($phone) ?>"></label><label>Địa chỉ<textarea name="address"><?= e($address) ?></textarea></label><button class="btn">Cập nhật</button></form>
    <p><a href="<?= e(url('change-password.php')) ?>">Đổi mật khẩu →</a></p>
</main><?php require 'includes/footer.php'; ?>