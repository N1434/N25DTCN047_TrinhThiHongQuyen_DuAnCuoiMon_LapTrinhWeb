<?php require 'includes/init.php';
require_login();
$id = (int)($_GET['id'] ?? 0);
$q = $pdo->prepare('SELECT * FROM orders WHERE id=? AND user_id=?');
$q->execute([$id, current_user()['id']]);
$o = $q->fetch();
if (!$o) {
    http_response_code(404);
    require '404.php';
    exit;
}
$q = $pdo->prepare('SELECT * FROM order_items WHERE order_id=?');
$q->execute([$id]);
$pageTitle = 'Đơn hàng #' . $id;
require 'includes/header.php'; ?><main class="container section"><a class="back" href="<?= e(url('orders.php')) ?>">← Lịch sử đơn hàng</a>
    <h1>Đơn hàng #<?= $id ?></h1>
    <p>Trạng thái: <span class="pill"><?= e(status_label($o['status'])) ?></span> · Ngày đặt: <?= e($o['created_at']) ?></p>
    <p>Người nhận: <?= e($o['customer_name']) ?> · <?= e($o['phone']) ?></p>
    <p>Địa chỉ: <?= e($o['address']) ?></p>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Đơn giá</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody><?php foreach ($q as $i): ?><tr>
                        <td><?= e($i['product_name']) ?></td>
                        <td><?= $i['quantity'] ?></td>
                        <td><?= money($i['unit_price']) ?></td>
                        <td><?= money($i['unit_price'] * $i['quantity']) ?></td>
                    </tr><?php endforeach; ?></tbody>
        </table>
    </div>
    <h2>Tổng cộng: <?= money($o['total']) ?></h2><?php if ($o['status'] === 'pending'): ?><form method="post" action="<?= e(url('order-cancel.php')) ?>" data-confirm="Bạn muốn hủy đơn này?"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $id ?>"><button class="btn danger-bg">Hủy đơn hàng</button></form><?php endif; ?>
</main><?php require 'includes/footer.php'; ?>