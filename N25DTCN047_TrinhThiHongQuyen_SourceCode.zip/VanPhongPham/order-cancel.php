<?php require 'includes/init.php';
require_login();
post_only();
$id = (int)($_POST['id'] ?? 0);
try {
    $pdo->beginTransaction();
    $q = $pdo->prepare('SELECT id,status FROM orders WHERE id=? AND user_id=? FOR UPDATE');
    $q->execute([$id, current_user()['id']]);
    $o = $q->fetch();
    if (!$o || $o['status'] !== 'pending') throw new RuntimeException('Chỉ hủy được đơn đang chờ xử lý.');
    $q = $pdo->prepare('SELECT product_id,quantity FROM order_items WHERE order_id=?');
    $q->execute([$id]);
    foreach ($q as $i) {
        $u = $pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?');
        $u->execute([$i['quantity'], $i['product_id']]);
    }
    $u = $pdo->prepare("UPDATE orders SET status='cancelled' WHERE id=?");
    $u->execute([$id]);
    $pdo->commit();
    flash('Đã hủy đơn và hoàn lại tồn kho.');
} catch (Throwable $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    flash($ex instanceof RuntimeException ? $ex->getMessage() : 'Không thể hủy đơn.', 'bad');
}
go('orders.php');
