<?php require '../includes/init.php';
require_admin();
post_only();
$id = (int)($_POST['id'] ?? 0);
$q = $pdo->prepare('SELECT COUNT(*) FROM order_items WHERE product_id=?');
$q->execute([$id]);
if ($q->fetchColumn()) {
    flash('Không thể xóa sản phẩm đã có trong đơn hàng.', 'bad');
    go('admin/products.php');
}
$p = get_product($pdo, $id);
if ($p) {
    $q = $pdo->prepare('DELETE FROM products WHERE id=?');
    $q->execute([$id]);
    delete_upload($p['image']);
    flash('Đã xóa sản phẩm.');
}
go('admin/products.php');
