<?php require '../includes/init.php';
require_admin();
$status = (string)($_GET['status'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $new = (string)($_POST['status'] ?? '');
    if (valid_status($new)) {
        try {
            $pdo->beginTransaction();
            $q = $pdo->prepare('SELECT status FROM orders WHERE id=? FOR UPDATE');
            $q->execute([$id]);
            $old = $q->fetchColumn();
            if ($old === false) throw new RuntimeException('Không tìm thấy đơn.');
            if ($old === 'cancelled' && $new !== 'cancelled') throw new RuntimeException('Không thể mở lại đơn đã hủy.');
            if ($old !== 'cancelled' && $new === 'cancelled') {
                $q = $pdo->prepare('SELECT product_id,quantity FROM order_items WHERE order_id=?');
                $q->execute([$id]);
                foreach ($q as $i) {
                    $u = $pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?');
                    $u->execute([$i['quantity'], $i['product_id']]);
                }
            }
            $q = $pdo->prepare('UPDATE orders SET status=? WHERE id=?');
            $q->execute([$new, $id]);
            $pdo->commit();
            flash('Cập nhật trạng thái thành công.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('Không thể cập nhật trạng thái đơn.', 'bad');
        }
    }
    go('admin/orders.php');
}
$params = [];
$sql = 'SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id';
if (valid_status($status)) {
    $sql .= ' WHERE o.status=?';
    $params[] = $status;
}
$sql .= ' ORDER BY o.id DESC';
$q = $pdo->prepare($sql);
$q->execute($params);
$pageTitle = 'Quản lý đơn hàng';
require '../includes/header.php'; ?><main class="container section">
    <h1>Quản lý đơn hàng</h1><?php require '../includes/admin-nav.php'; ?><form class="filters" method="get"><label>Trạng thái<select name="status">
                <option value="">Tất cả</option><?php foreach (['pending', 'shipping', 'completed', 'cancelled'] as $s): ?><option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
            </select></label><button class="btn">Lọc</button></form>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Khách hàng</th>
                    <th>Ngày</th>
                    <th>Giá trị</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody><?php foreach ($q as $o): ?><tr>
                        <td>#<?= $o['id'] ?></td>
                        <td><?= e($o['customer_name']) ?><br><small><?= e($o['email']) ?></small></td>
                        <td><?= e($o['created_at']) ?></td>
                        <td><?= money($o['total']) ?></td>
                        <td>
                            <form method="post" class="inline-edit"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><select name="status" <?= $o['status'] === 'cancelled' ? 'disabled' : '' ?>><?php foreach (['pending', 'shipping', 'completed', 'cancelled'] as $s): ?><option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?></select><button class="btn-ghost" <?= $o['status'] === 'cancelled' ? 'disabled' : '' ?>>Lưu</button></form>
                        </td>
                    </tr><?php endforeach; ?></tbody>
        </table>
    </div>
</main><?php require '../includes/footer.php'; ?>