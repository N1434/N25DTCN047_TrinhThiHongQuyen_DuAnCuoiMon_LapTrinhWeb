<?php require '../includes/init.php';
require_admin();
$stats = $pdo->query('SELECT status,COUNT(*) cnt FROM orders GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);
$revenue = $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='completed'")->fetchColumn();
$low = $pdo->query('SELECT name,stock FROM products ORDER BY stock ASC,id ASC LIMIT 5');
$pageTitle = 'Quản trị tổng quan';
require '../includes/header.php'; ?><main class="container section">
    <h1>Quản trị cửa hàng</h1><?php require '../includes/admin-nav.php'; ?><div class="stat-grid"><?php foreach (['pending', 'shipping', 'completed', 'cancelled'] as $s): ?><div class="stat"><span><?= e(status_label($s)) ?></span><strong><?= (int)($stats[$s] ?? 0) ?></strong></div><?php endforeach; ?><div class="stat"><span>Doanh thu hoàn tất</span><strong><?= money($revenue) ?></strong></div>
    </div>
    <h2>5 sản phẩm sắp hết hàng</h2>
    <div class="table-wrap">
        <table class="data-table">
            <tr>
                <th>Sản phẩm</th>
                <th>Tồn kho</th>
            </tr><?php foreach ($low as $p): ?><tr>
                    <td><?= e($p['name']) ?></td>
                    <td><?= $p['stock'] ?></td>
                </tr><?php endforeach; ?>
        </table>
    </div>
</main><?php require '../includes/footer.php'; ?>