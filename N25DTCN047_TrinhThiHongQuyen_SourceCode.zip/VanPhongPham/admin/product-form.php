<?php require '../includes/init.php';
require_admin();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = $id ? get_product($pdo, $id) : null;
if ($id && !$p) {
    http_response_code(404);
    require '../404.php';
    exit;
}
$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$errors = [];
$name = trim((string)($_POST['name'] ?? $p['name'] ?? ''));
$description = trim((string)($_POST['description'] ?? $p['description'] ?? ''));
$price = (int)($_POST['price'] ?? $p['price'] ?? 0);
$stock = (int)($_POST['stock'] ?? $p['stock'] ?? 0);
$category = (int)($_POST['category_id'] ?? $p['category_id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (mb_strlen($name) < 2 || mb_strlen($description) < 8) $errors[] = 'Vui lòng nhập tên và mô tả đầy đủ.';
    if ($price < 1000 || $stock < 0) $errors[] = 'Giá phải từ 1.000đ, tồn kho không âm.';
    if (!in_array($category, array_column($categories, 'id'), false)) $errors[] = 'Danh mục không hợp lệ.';
    if (!$errors) {
        $newImage = null;
        try {
            $newImage = image_upload('image');
            if (!$id && !$newImage) throw new RuntimeException('Bạn cần tải ảnh sản phẩm.');
            $img = $newImage ?? $p['image'];
            if ($id) {
                $s = $pdo->prepare('UPDATE products SET category_id=?,name=?,description=?,price=?,stock=?,image=? WHERE id=?');
                $s->execute([$category, $name, $description, $price, $stock, $img, $id]);
                if ($newImage) delete_upload($p['image']);
            } else {
                $s = $pdo->prepare('INSERT INTO products(category_id,name,description,price,stock,image) VALUES(?,?,?,?,?,?)');
                $s->execute([$category, $name, $description, $price, $stock, $img]);
            }
            flash('Đã lưu sản phẩm.');
            go('admin/products.php');
        } catch (Throwable $ex) {
            if ($newImage) delete_upload($newImage);
            $errors[] = $ex instanceof RuntimeException ? $ex->getMessage() : 'Không thể lưu sản phẩm.';
        }
    }
}
$pageTitle = $id ? 'Sửa sản phẩm' : 'Thêm sản phẩm';
require '../includes/header.php'; ?><main class="container section narrow">
    <h1><?= e($pageTitle) ?></h1><?php require '../includes/admin-nav.php'; ?><?php foreach ($errors as $err): ?><div class="error"><?= e($err) ?></div><?php endforeach; ?><form class="form-card" method="post" enctype="multipart/form-data"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $id ?>"><label>Tên sản phẩm<input name="name" required minlength="2" value="<?= e($name) ?>"></label><label>Danh mục<select name="category_id" required><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $category == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label><label>Mô tả<textarea name="description" minlength="8" required><?= e($description) ?></textarea></label><label>Giá bán (VNĐ)<input type="number" name="price" min="1000" required value="<?= $price ?>"></label><label>Tồn kho<input type="number" name="stock" min="0" required value="<?= $stock ?>"></label><label>Ảnh sản phẩm (JPG, PNG, WebP; tối đa 2MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp" <?= $id ? '' : 'required' ?>></label><?php if ($p): ?><img class="preview" alt="Ảnh hiện tại" src="<?= e(url($p['image'])) ?>"><?php endif; ?><button class="btn">Lưu sản phẩm</button></form>
</main><?php require '../includes/footer.php'; ?>