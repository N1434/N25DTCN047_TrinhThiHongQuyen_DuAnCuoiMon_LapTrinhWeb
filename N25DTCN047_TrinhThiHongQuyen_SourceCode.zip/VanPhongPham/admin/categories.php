<?php require '../includes/init.php';
require_admin();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'add';
    $id = (int)($_POST['id'] ?? 0);
    $name = trim((string)($_POST['name'] ?? ''));
    try {
        if ($action === 'delete') {
            $q = $pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id=?');
            $q->execute([$id]);
            if ($q->fetchColumn()) throw new RuntimeException('Danh mục đang có sản phẩm nên không thể xóa.');
            $q = $pdo->prepare('DELETE FROM categories WHERE id=?');
            $q->execute([$id]);
        } else {
            if (mb_strlen($name) < 2) throw new RuntimeException('Tên danh mục quá ngắn.');
            if ($action === 'edit') {
                $q = $pdo->prepare('UPDATE categories SET name=? WHERE id=?');
                $q->execute([$name, $id]);
            } else {
                $q = $pdo->prepare('INSERT INTO categories(name) VALUES(?)');
                $q->execute([$name]);
            }
        }
        flash('Đã cập nhật danh mục.');
        go('admin/categories.php');
    } catch (Throwable $ex) {
        $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'Tên danh mục đã tồn tại hoặc dữ liệu không hợp lệ.';
    }
}
$categories = $pdo->query('SELECT c.id,c.name,COUNT(p.id) total FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id,c.name ORDER BY c.id');
$pageTitle = 'Danh mục';
require '../includes/header.php'; ?><main class="container section">
    <h1>Quản lý danh mục</h1><?php require '../includes/admin-nav.php'; ?><?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?><form class="form-card compact" method="post"><?= csrf_input() ?><input type="hidden" name="action" value="add"><label>Tên danh mục mới<input name="name" minlength="2" required></label><button class="btn">Thêm danh mục</button></form>
<div class="table-wrap">
    <table class="data-table">
        <tr>
            <th>Tên</th>
            <th>Số sản phẩm</th>
            <th>Thao tác</th>
        </tr><?php foreach ($categories as $c): ?><tr>
                <td>
                    <form method="post" class="inline-edit"><?= csrf_input() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= $c['id'] ?>"><input name="name" value="<?= e($c['name']) ?>" required><button class="btn-ghost">Đổi tên</button></form>
                </td>
                <td><?= $c['total'] ?></td>
                <td>
                    <form method="post" class="inline-form" data-confirm="Xóa danh mục này?"><?= csrf_input() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="btn-ghost danger">Xóa</button></form>
                </td>
            </tr><?php endforeach; ?>
    </table>
</div>
</main><?php require '../includes/footer.php'; ?>