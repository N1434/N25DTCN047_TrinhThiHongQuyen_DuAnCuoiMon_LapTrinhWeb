<?php require '../includes/init.php';
require_admin();
$page = max(1, (int)($_GET['page'] ?? 1));
$count = (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
$pages = max(1, (int)ceil($count / 10));
$page = min($page, $pages);
$q = $pdo->query('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC LIMIT 10 OFFSET ' . (($page - 1) * 10));
$pageTitle = 'Quản lý sản phẩm';
require '../includes/header.php'; ?><main class="container section">
    <h1>Quản lý sản phẩm</h1><?php require '../includes/admin-nav.php'; ?><p><a class="btn" href="<?= e(url('admin/product-form.php')) ?>">+ Thêm sản phẩm</a></p>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ảnh</th>
                    <th>Sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Giá</th>
                    <th>Tồn</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody><?php foreach ($q as $p): ?><tr>
                        <td><img class="tiny-product" src="<?= e(url($p['image'])) ?>" alt="<?= e($p['name']) ?>"></td>
                        <td><?= e($p['name']) ?></td>
                        <td><?= e($p['category_name']) ?></td>
                        <td><?= money($p['price']) ?></td>
                        <td><?= $p['stock'] ?></td>
                        <td><a href="<?= e(url('admin/product-form.php?id=' . $p['id'])) ?>">Sửa</a> · <form class="inline-form" method="post" action="<?= e(url('admin/product-delete.php')) ?>" data-confirm="Xóa sản phẩm này?"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn-ghost danger">Xóa</button></form>
                        </td>
                    </tr><?php endforeach; ?></tbody>
        </table>
    </div>
    <div class="pagination"><?php for ($i = 1; $i <= $pages; $i++): ?><a class="<?= $i === $page ? 'active' : '' ?>" href="<?= e(url('admin/products.php?page=' . $i)) ?>"><?= $i ?></a><?php endfor; ?></div>
</main><?php require '../includes/footer.php'; ?>