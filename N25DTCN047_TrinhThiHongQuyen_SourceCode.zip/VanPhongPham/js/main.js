"use strict";
document.querySelectorAll("[data-confirm]").forEach((form) =>
  form.addEventListener("submit", (ev) => {
    if (!window.confirm(form.dataset.confirm || "Bạn chắc chắn?"))
      ev.preventDefault();
  }),
);
document
  .querySelectorAll("[data-register], [data-password]")
  .forEach((form) => {
    const password = form.querySelector('[name="password"], [name="new"]');

    const confirmPassword = form.querySelector('[name="confirm"]');

    if (!password || !confirmPassword) return;

    function validatePasswords() {
      if (password.value !== confirmPassword.value) {
        confirmPassword.setCustomValidity("Hai mật khẩu không khớp nhau!");
      } else {
        confirmPassword.setCustomValidity("");
      }
    }

    password.addEventListener("input", validatePasswords);
    confirmPassword.addEventListener("input", validatePasswords);

    form.addEventListener("submit", function (event) {
      validatePasswords();

      if (!confirmPassword.checkValidity()) {
        event.preventDefault();
        confirmPassword.reportValidity();
      }
    });
  });
document.querySelectorAll("[data-contact]").forEach((form) =>
  form.addEventListener("submit", (ev) => {
    const field = form.querySelector('[name="message"]');
    if (field.value.trim().length < 10) {
      ev.preventDefault();
      field.setCustomValidity("Vui lòng nhập tối thiểu 10 ký tự.");
      field.reportValidity();
    } else field.setCustomValidity("");
  }),
);
const formatter = new Intl.NumberFormat("vi-VN", {
  style: "currency",
  currency: "VND",
  maximumFractionDigits: 0,
});
function recalcCart() {
  let sum = 0;
  document.querySelectorAll("[data-price]").forEach((row) => {
    const price = Number(row.dataset.price),
      qty = Number(row.querySelector("[data-qty]").value) || 0,
      subtotal = price * qty;
    row.querySelector("[data-subtotal]").textContent =
      formatter.format(subtotal);
    sum += subtotal;
  });
  const total = document.querySelector("#cart-total");
  if (total) total.textContent = formatter.format(sum);
}
document
  .querySelectorAll("[data-qty]")
  .forEach((input) => input.addEventListener("input", recalcCart));
