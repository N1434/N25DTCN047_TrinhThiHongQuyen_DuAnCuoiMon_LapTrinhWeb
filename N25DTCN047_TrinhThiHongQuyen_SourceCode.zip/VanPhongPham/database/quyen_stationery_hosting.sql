-- Seed data for quyen stationery shop. Import into MySQL 8 / MariaDB.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS contacts;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS categories;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE products (id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NOT NULL,name VARCHAR(200) NOT NULL,description TEXT NOT NULL,price DECIMAL(12,2) NOT NULL,stock INT NOT NULL DEFAULT 0,image VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_product_cat FOREIGN KEY(category_id) REFERENCES categories(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,role ENUM('admin','customer') NOT NULL DEFAULT 'customer',phone VARCHAR(30) NOT NULL DEFAULT '',address TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE orders (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,customer_name VARCHAR(120) NOT NULL,phone VARCHAR(30) NOT NULL,address TEXT NOT NULL,total DECIMAL(12,2) NOT NULL,status ENUM('pending','shipping','completed','cancelled') NOT NULL DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_order_user FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE order_items (id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,product_id INT NOT NULL,product_name VARCHAR(200) NOT NULL,quantity INT NOT NULL,unit_price DECIMAL(12,2) NOT NULL,CONSTRAINT fk_item_order FOREIGN KEY(order_id) REFERENCES orders(id),CONSTRAINT fk_item_product FOREIGN KEY(product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE contacts (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,name VARCHAR(120) NOT NULL,email VARCHAR(190) NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_contact_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO categories(id,name) VALUES (1,'Sổ tay & Giấy'),(2,'Bút & Dụng cụ viết'),(3,'Phụ kiện bàn học');
INSERT INTO products(id,category_id,name,description,price,stock,image) VALUES
(1,1,'Sổ tay Pastel A5','Sổ ghi chú bìa pastel, giấy kem 80 gsm, 120 trang.',45000,38,'images/product-01.svg'),
(2,1,'Sổ lò xo Campus','Sổ lò xo 100 trang, dòng kẻ rõ, dễ ghi chép.',39000,52,'images/product-02.svg'),
(3,1,'Planner tuần Bloom','Sổ lên kế hoạch tuần với bố cục linh hoạt.',68000,24,'images/product-03.svg'),
(4,1,'Sticky Notes Hoa Nhỏ','Giấy ghi chú nhiều màu, dễ bóc dán.',25000,75,'images/product-04.svg'),
(5,2,'Bút gel Mực Đen 0.5','Bút mực gel nét 0.5 mm, viết êm, nhanh khô.',16000,120,'images/product-05.svg'),
(6,2,'Bút highlight Sorbet','Bộ bút nhớ dòng tông màu nhẹ mắt.',33000,48,'images/product-06.svg'),
(7,2,'Bút bi Vintage','Bút bi thân nhám sang trọng, ngòi 0.7 mm.',22000,62,'images/product-07.svg'),
(8,2,'Bộ bút màu Creative','Bộ 12 bút màu cho ghi chú và trang trí.',85000,30,'images/product-08.svg'),
(9,3,'Hộp bút Linen','Hộp bút vải canvas khóa kéo bền đẹp.',79000,18,'images/product-09.svg'),
(10,3,'Kẹp giấy Gold Star','Bộ kẹp giấy kim loại nhỏ gọn, hình ngôi sao.',29000,67,'images/product-10.svg'),
(11,3,'Giá đỡ sách Gỗ','Giá sách mini giúp bàn học ngăn nắp.',129000,12,'images/product-11.svg'),
(12,3,'Thước gỗ Mini 20cm','Thước gỗ 20 cm, khắc vạch rõ nét.',19000,88,'images/product-12.svg');
INSERT INTO users(id,name,email,password,role,phone,address) VALUES
(1,'Quản trị viên','admin@quyenshop.test','$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi','admin','0900000001','TP. Hồ Chí Minh'),
(2,'Nguyễn Minh Anh','minhanh@example.test','$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi','customer','0900000002','12 Lê Lợi, TP. Hồ Chí Minh'),
(3,'Trần Gia Hân','giahan@example.test','$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi','customer','0900000003','25 Hai Bà Trưng, TP. Hồ Chí Minh');
INSERT INTO orders(id,user_id,customer_name,phone,address,total,status) VALUES
(1,2,'Nguyễn Minh Anh','0900000002','12 Lê Lợi, TP. Hồ Chí Minh',84000,'pending'),
(2,3,'Trần Gia Hân','0900000003','25 Hai Bà Trưng, TP. Hồ Chí Minh',115000,'shipping'),
(3,2,'Nguyễn Minh Anh','0900000002','12 Lê Lợi, TP. Hồ Chí Minh',129000,'completed'),
(4,3,'Trần Gia Hân','0900000003','25 Hai Bà Trưng, TP. Hồ Chí Minh',33000,'cancelled'),
(5,2,'Nguyễn Minh Anh','0900000002','12 Lê Lợi, TP. Hồ Chí Minh',79000,'completed');
INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES
(1,1,'Sổ tay Pastel A5',1,45000),
(1,2,'Sổ lò xo Campus',1,39000),
(2,3,'Planner tuần Bloom',1,68000),
(2,4,'Sticky Notes Hoa Nhỏ',1,25000),
(2,7,'Bút bi Vintage',1,22000),
(3,11,'Giá đỡ sách Gỗ',1,129000),
(4,6,'Bút highlight Sorbet',1,33000),
(5,9,'Hộp bút Linen',1,79000);
INSERT INTO contacts(name,email,message) VALUES ('Khách hàng mẫu','contact@example.test','Mình muốn hỏi về bộ sổ tay pastel.');
