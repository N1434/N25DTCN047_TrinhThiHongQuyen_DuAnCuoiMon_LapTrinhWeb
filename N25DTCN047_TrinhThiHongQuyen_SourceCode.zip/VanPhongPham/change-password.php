<?php require 'includes/init.php';
require_login();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $q = $pdo->prepare('SELECT password FROM users WHERE id=?');
    $q->execute([current_user()['id']]);
    $hash = $q->fetchColumn();
    $new = (string)($_POST['new'] ?? '');
    if (!password_verify((string)($_POST['old'] ?? ''), $hash)) $error = 'Mật khẩu hiện tại không đúng.';
    elseif (strlen($new) < 8) $error = 'Mật khẩu mới phải có ít nhất 8 ký tự.';
    elseif ($new !== ($_POST['confirm'] ?? '')) $error = 'Mật khẩu xác nhận không khớp.';
    else {
        $q = $pdo->prepare('UPDATE users SET password=? WHERE id=?');
        $q->execute([password_hash($new, PASSWORD_DEFAULT), current_user()['id']]);
        flash('Đổi mật khẩu thành công.');
        go('profile.php');
    }
}
$pageTitle = 'Đổi mật khẩu';
require 'includes/header.php'; ?><main class="container section narrow">
    <h1>Đổi mật khẩu</h1><?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?><form class="form-card" method="post" data-password><?= csrf_input() ?><label>Mật khẩu hiện tại<input type="password" name="old" required></label><label>Mật khẩu mới<input type="password" name="new" minlength="8" required></label><label>Nhập lại mật khẩu<input type="password" name="confirm" minlength="8" required></label><button class="btn">Lưu mật khẩu mới</button></form>
</main><?php require 'includes/footer.php'; ?>