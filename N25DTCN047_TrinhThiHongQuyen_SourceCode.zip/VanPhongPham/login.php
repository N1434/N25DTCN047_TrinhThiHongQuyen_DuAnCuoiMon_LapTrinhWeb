<?php require 'includes/init.php';
if (current_user()) go();
$pageTitle = 'Đăng nhập';
$error = '';
$email = trim((string)($_POST['email'] ?? ''));
$locked = ($_SESSION['login_locked_until'] ?? 0) > time();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if ($locked) {
        $error = 'Bạn đã nhập sai 5 lần. Thử lại sau ' . ceil(($_SESSION['login_locked_until'] - time()) / 60) . ' phút.';
    } else {
        $s = $pdo->prepare('SELECT * FROM users WHERE email=?');
        $s->execute([$email]);
        $user = $s->fetch();
        if ($user && password_verify((string)($_POST['password'] ?? ''), $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => (int)$user['id'], 'name' => $user['name'], 'role' => $user['role']];
            unset($_SESSION['login_fails'], $_SESSION['login_locked_until']);
            flash('Chào mừng ' . $user['name'] . '!');
            $next = $_SESSION['after_login'] ?? 'index.php';
            unset($_SESSION['after_login']);
            if (str_starts_with($next, BASE_URL . '/')) $next = substr($next, strlen(BASE_URL) + 1);
            go(safe_next($next));
        } else {
            $_SESSION['login_fails'] = ($_SESSION['login_fails'] ?? 0) + 1;
            if ($_SESSION['login_fails'] >= 5) {
                $_SESSION['login_locked_until'] = time() + 300;
                $_SESSION['login_fails'] = 0;
                $locked = true;
                $error = 'Sai mật khẩu 5 lần, đăng nhập bị khóa trong 5 phút.';
            } else $error = 'Email hoặc mật khẩu không đúng. Còn ' . (5 - $_SESSION['login_fails']) . ' lần thử.';
        }
    }
}
require 'includes/header.php'; ?><main class="container section narrow">
    <h1>Đăng nhập</h1><?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?><form class="form-card" method="post"><?= csrf_input() ?><label>Email<input type="email" name="email" required value="<?= e($email) ?>" <?= $locked ? 'disabled' : '' ?>></label><label>Mật khẩu<input type="password" name="password" required <?= $locked ? 'disabled' : '' ?>></label><button class="btn" <?= $locked ? 'disabled' : '' ?>>Đăng nhập</button></form>
    <p>Chưa có tài khoản? <a href="<?= e(url('register.php')) ?>">Đăng ký</a></p>
</main><?php require 'includes/footer.php'; ?>