<?php if (!isset($pdo)) require 'includes/init.php';
http_response_code(404);
$pageTitle = 'Không tìm thấy trang';
require 'includes/header.php'; ?><main class="container section">
    <div class="empty">
        <h1>404</h1>
        <p>Trang hoặc sản phẩm bạn tìm kiếm không tồn tại.</p><a class="btn" href="<?= e(url()) ?>">Quay về trang chủ</a>
    </div>
</main><?php require 'includes/footer.php'; ?>