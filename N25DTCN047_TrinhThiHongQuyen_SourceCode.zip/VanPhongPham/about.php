<?php require 'includes/init.php';
$pageTitle = 'Giới thiệu';
require 'includes/header.php'; ?><main class="container section article"><span class="eyebrow">CÂU CHUYỆN CỦA CHÚNG MÌNH</span>
    <h1>Chút cảm hứng cho mỗi ngày</h1>
    <p><?= e(STORE_NAME) ?> chọn lọc các sản phẩm văn phòng phẩm tiện dụng, trẻ trung với mức giá dễ tiếp cận. Từ sổ tay, bút viết đến phụ kiện bàn học, mỗi món đồ đều giúp góc làm việc thêm gọn gàng và thú vị.</p>
    <p>Chúng mình tin rằng những thói quen học tập tích cực bắt đầu từ không gian nhỏ được chăm chút mỗi ngày.</p><a class="btn" href="<?= e(url()) ?>">Khám phá bộ sưu tập</a>
</main><?php require 'includes/footer.php'; ?>