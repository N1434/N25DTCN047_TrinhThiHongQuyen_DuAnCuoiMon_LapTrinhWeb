<?php require 'includes/init.php';
$p = get_product($pdo, (int)($_GET['id'] ?? 0));
if (!$p) {
    http_response_code(404);
    require '404.php';
    exit;
}
$pageTitle = $p['name'];
$q = $pdo->prepare('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.category_id=? AND p.id<>? ORDER BY p.id DESC LIMIT 3');
$q->execute([$p['category_id'], $p['id']]);
require 'includes/header.php'; ?>
<main class="container section"><a class="back" href="<?= e(url()) ?>">← Quay lại sản phẩm</a>
    <div class="detail"><img src="<?= e(url($p['image'])) ?>" alt="<?= e($p['name']) ?>">
        <div><span class="eyebrow"><?= e($p['category_name']) ?></span>
            <h1><?= e($p['name']) ?></h1>
            <div class="big-price"><?= money($p['price']) ?></div>
            <p><?= nl2br(e($p['description'])) ?></p>
            <table class="spec">
                <tr>
                    <th>Mã sản phẩm</th>
                    <td>#<?= $p['id'] ?></td>
                </tr>
                <tr>
                    <th>Danh mục</th>
                    <td><?= e($p['category_name']) ?></td>
                </tr>
                <tr>
                    <th>Giá bán</th>
                    <td><?= money($p['price']) ?></td>
                </tr>
                <tr>
                    <th>Tồn kho</th>
                    <td><?= $p['stock'] ?></td>
                </tr>
            </table>
            <form method="post" action="<?= e(url('cart-add.php')) ?>" class="add-row"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><label>Số lượng <input type="number" name="qty" value="1" min="1" max="<?= max(1, $p['stock']) ?>"></label><button class="btn" <?= $p['stock'] < 1 ? 'disabled' : '' ?>>Thêm vào giỏ</button></form>
        </div>
    </div>
    <h2 class="related-title">Có thể bạn cũng thích</h2>
    <div class="product-grid related"><?php foreach ($q as $r) product_card($r); ?></div>
</main><?php require 'includes/footer.php'; ?>