<?php require 'includes/init.php';
$category = max(0, (int)($_GET['category'] ?? 0));
$keyword = trim((string)($_GET['q'] ?? ''));
$sort = (string)($_GET['sort'] ?? 'new');
$page = max(1, (int)($_GET['page'] ?? 1));
$orders = ['new' => 'p.id DESC', 'asc' => 'p.price ASC', 'desc' => 'p.price DESC'];
$orderBy = $orders[$sort] ?? $orders['new'];
$where = [];
$params = [];
if ($category) {
    $where[] = 'p.category_id=?';
    $params[] = $category;
}
if ($keyword !== '') {
    $where[] = 'p.name LIKE ?';
    $params[] = '%' . $keyword . '%';
}
$filter = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$count = $pdo->prepare('SELECT COUNT(*) FROM products p' . $filter);
$count->execute($params);
$total = (int)$count->fetchColumn();
$maxPage = max(1, (int)ceil($total / 8));
$page = min($page, $maxPage);
$q = $pdo->prepare('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id' . $filter . ' ORDER BY ' . $orderBy . ' LIMIT 8 OFFSET ' . (($page - 1) * 8));
$q->execute($params);
$products = $q->fetchAll();
$categories = $pdo->query('SELECT id,name FROM categories ORDER BY name')->fetchAll();
$pageTitle = 'Sản phẩm';
require 'includes/header.php'; ?>
<main>
    <section class="hero">
        <div class="container hero-layout">
            <div><span class="eyebrow">BỘ SƯU TẬP VĂN PHÒNG PHẨM</span>
                <h1>Niềm vui nhỏ<br>trên từng trang giấy.</h1>
                <p>Khám phá những món đồ học tập xinh xắn, tiện dụng và đầy sắc màu.</p><a class="btn" href="#catalog">Khám phá ngay →</a>
            </div>
            <div class="hero-art"><span>✎</span><span>✿</span><span>▤</span>
                <p>HỌC TẬP • SÁNG TẠO • CẢM HỨNG</p>
            </div>
        </div>
    </section>
    <section class="container section" id="catalog">
        <div class="section-head">
            <div><span class="eyebrow">DÀNH CHO BẠN</span>
                <h2>Sản phẩm nổi bật</h2>
                <p class="muted">Tìm thấy <strong><?= $total ?></strong> sản phẩm</p>
            </div>
        </div>
        <form class="filters" method="get"><label>Danh mục<select name="category">
                    <option value="0">Tất cả danh mục</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $category === $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
                </select></label><label>Tìm kiếm<input name="q" value="<?= e($keyword) ?>" placeholder="Tên sản phẩm..."></label><label>Sắp xếp<select name="sort">
                    <option value="new" <?= $sort === 'new' ? 'selected' : '' ?>>Mới nhất</option>
                    <option value="asc" <?= $sort === 'asc' ? 'selected' : '' ?>>Giá tăng dần</option>
                    <option value="desc" <?= $sort === 'desc' ? 'selected' : '' ?>>Giá giảm dần</option>
                </select></label><button class="btn">Áp dụng</button></form>
        <?php if ($products): ?><div class="product-grid"><?php foreach ($products as $p) product_card($p); ?></div><?php else: ?><div class="empty">Không tìm thấy sản phẩm phù hợp.</div><?php endif; ?>
        <?php if ($maxPage > 1): ?><div class="pagination"><?php for ($n = 1; $n <= $maxPage; $n++): ?><a class="<?= $n === $page ? 'active' : '' ?>" href="<?= e(url('index.php?' . http_build_query(['category' => $category, 'q' => $keyword, 'sort' => $sort, 'page' => $n]))) ?>"><?= $n ?></a><?php endfor; ?></div><?php endif; ?>
    </section>
</main><?php require 'includes/footer.php'; ?>