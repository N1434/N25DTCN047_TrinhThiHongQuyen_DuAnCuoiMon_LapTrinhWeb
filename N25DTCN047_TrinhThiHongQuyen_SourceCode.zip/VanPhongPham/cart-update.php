<?php require 'includes/init.php';
post_only();
$action = $_POST['action'] ?? 'update';
if ($action === 'clear') {
    $_SESSION['cart'] = [];
    flash('Đã xóa giỏ hàng.');
    go('cart.php');
}
$id = (int)($_POST['id'] ?? 0);
if ($action === 'remove') unset($_SESSION['cart'][$id]);
else {
    $p = get_product($pdo, $id);
    if ($p) {
        $qty = max(0, min(99, (int)($_POST['qty'] ?? 1), $p['stock']));
        if ($qty) $_SESSION['cart'][$id] = $qty;
        else unset($_SESSION['cart'][$id]);
    }
}
go('cart.php');
