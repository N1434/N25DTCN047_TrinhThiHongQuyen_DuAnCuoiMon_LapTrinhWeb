<?php require 'includes/init.php';
require_login();
$lines = cart_lines($pdo);
if (!$lines) {
    flash('Giỏ hàng trống.', 'bad');
    go('cart.php');
}
$u = $pdo->prepare('SELECT * FROM users WHERE id=?');
$u->execute([current_user()['id']]);
$user = $u->fetch();
$name = trim((string)($_POST['name'] ?? $user['name']));
$phone = trim((string)($_POST['phone'] ?? $user['phone']));
$address = trim((string)($_POST['address'] ?? $user['address']));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (mb_strlen($name) < 2 || !preg_match('/^[0-9+ .-]{9,16}$/', $phone) || mb_strlen($address) < 8) $error = 'Vui lòng nhập đủ họ tên, số điện thoại và địa chỉ hợp lệ.';
    else {
        try {
            $pdo->beginTransaction();
            $grand = 0;
            $items = [];
            foreach ($lines as $line) {
                $s = $pdo->prepare('SELECT id,name,price,stock FROM products WHERE id=? FOR UPDATE');
                $s->execute([$line['id']]);
                $live = $s->fetch();
                if (!$live || $live['stock'] < $line['qty']) throw new RuntimeException('Sản phẩm ' . $line['name'] . ' không đủ tồn kho.');
                $grand += (float)$live['price'] * $line['qty'];
                $items[] = [$live, $line['qty']];
            }
            $s = $pdo->prepare('INSERT INTO orders(user_id,customer_name,phone,address,total,status) VALUES(?,?,?,?,?,?)');
            $s->execute([current_user()['id'], $name, $phone, $address, $grand, 'pending']);
            $orderId = (int)$pdo->lastInsertId();
            foreach ($items as [$p, $qty]) {
                $s = $pdo->prepare('INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)');
                $s->execute([$orderId, $p['id'], $p['name'], $qty, $p['price']]);
                $s = $pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
                $s->execute([$qty, $p['id']]);
            }
            $pdo->commit();
            $_SESSION['cart'] = [];
            flash('Đặt hàng thành công!');
            go('order-detail.php?id=' . $orderId);
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'Không thể đặt hàng. Vui lòng thử lại.';
        }
    }
}
$pageTitle = 'Thanh toán';
require 'includes/header.php'; ?><main class="container section narrow">
    <h1>Thông tin đặt hàng</h1><?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?><form class="form-card" method="post"><?= csrf_input() ?><label>Họ tên người nhận<input name="name" required minlength="2" value="<?= e($name) ?>"></label><label>Số điện thoại<input name="phone" required pattern="[0-9+ .-]{9,16}" value="<?= e($phone) ?>"></label><label>Địa chỉ giao hàng<textarea name="address" required minlength="8"><?= e($address) ?></textarea></label>
        <h3>Đơn hàng (<?= count($lines) ?> mặt hàng)</h3><?php foreach ($lines as $p): ?><p><?= e($p['name']) ?> × <?= $p['qty'] ?> <strong class="float-right"><?= money($p['subtotal']) ?></strong></p><?php endforeach; ?><h3>Tổng cộng: <?= money(array_sum(array_column($lines, 'subtotal'))) ?></h3><button class="btn">Xác nhận đặt hàng</button>
    </form>
</main><?php require 'includes/footer.php'; ?>