<?php
declare(strict_types=1);
const APP_DEBUG = false;
const BASE_URL = ''; 
const STORE_NAME = 'Cửa hàng Trịnh Thị Hồng Quyên';
const STUDENT_NAME = 'Trịnh Thị Hồng Quyên';
const STUDENT_ID = 'N25DTCN047';
const MAX_UPLOAD_BYTES = 2097152;
