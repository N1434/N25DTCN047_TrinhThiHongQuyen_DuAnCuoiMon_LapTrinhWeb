<?php

const DB_HOST = 'sql301.infinityfree.com';

const DB_NAME = 'if0_43373407_quyen_stationery';

const DB_USER = 'if0_43373407';

const DB_PASS = '2xRzgPePR34xrV7';
