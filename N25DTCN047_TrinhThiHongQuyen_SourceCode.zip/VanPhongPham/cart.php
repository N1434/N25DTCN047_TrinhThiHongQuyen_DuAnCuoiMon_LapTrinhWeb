<?php require 'includes/init.php';
$lines = cart_lines($pdo);
$total = array_sum(array_column($lines, 'subtotal'));
$pageTitle = 'Giỏ hàng';
require 'includes/header.php'; ?><main class="container section">
    <h1>Giỏ hàng của bạn</h1><?php if (!$lines): ?><div class="empty">
            <p>Giỏ hàng đang trống.</p><a class="btn" href="<?= e(url()) ?>">Tiếp tục mua sắm</a>
        </div><?php else: ?><div class="table-wrap">
            <table class="data-table cart-table">
                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Đơn giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody><?php foreach ($lines as $p): ?><tr data-price="<?= $p['price'] ?>">
                            <td><a href="<?= e(url('product.php?id=' . $p['id'])) ?>"><img class="tiny-product" src="<?= e(url($p['image'])) ?>" alt="<?= e($p['name']) ?>"><?= e($p['name']) ?></a></td>
                            <td><?= money($p['price']) ?></td>
                            <td>
                                <form method="post" action="<?= e(url('cart-update.php')) ?>" class="qty-form"><?= csrf_input() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="number" min="0" max="<?= min(99, $p['stock']) ?>" name="qty" value="<?= $p['qty'] ?>" data-qty><button class="btn-ghost">Lưu</button></form>
                            </td>
                            <td data-subtotal><?= money($p['subtotal']) ?></td>
                            <td>
                                <form method="post" action="<?= e(url('cart-update.php')) ?>" data-confirm="Xóa sản phẩm này?"><?= csrf_input() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn-ghost danger">Xóa</button></form>
                            </td>
                        </tr><?php endforeach; ?></tbody>
            </table>
        </div>
        <div class="cart-bottom">
            <form method="post" action="<?= e(url('cart-update.php')) ?>" data-confirm="Bạn chắc chắn muốn xóa toàn bộ giỏ hàng?"><?= csrf_input() ?><input type="hidden" name="action" value="clear"><button class="btn-ghost danger">Xóa giỏ hàng</button></form>
            <div>
                <p>Tổng tiền: <strong id="cart-total"><?= money($total) ?></strong></p><a class="btn" href="<?= e(url('checkout.php')) ?>">Tiến hành đặt hàng</a>
            </div>
        </div><?php endif; ?>
</main><?php require 'includes/footer.php'; ?>