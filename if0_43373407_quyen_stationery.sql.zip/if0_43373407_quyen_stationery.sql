-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: sql301.infinityfree.com
-- Thời gian đã tạo: Th10 06, 2026 lúc 11:24 AM
-- Phiên bản máy phục vụ: 11.4.13-MariaDB
-- Phiên bản PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `if0_43373407_quyen_stationery`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(2, 'Bút & Dụng cụ viết'),
(3, 'Phụ kiện bàn học'),
(1, 'Sổ tay & Giấy');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `contacts`
--

INSERT INTO `contacts` (`id`, `user_id`, `name`, `email`, `message`, `created_at`) VALUES
(1, NULL, 'Khách hàng mẫu', 'contact@example.test', 'Mình muốn hỏi về bộ sổ tay pastel.', '2026-11-06 14:39:56');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(120) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `status` enum('pending','shipping','completed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `customer_name`, `phone`, `address`, `total`, `status`, `created_at`) VALUES
(1, 2, 'Nguyễn Minh Anh', '0900000002', '12 Lê Lợi, TP. Hồ Chí Minh', '84000.00', 'pending', '2026-11-06 14:39:56'),
(2, 3, 'Trần Gia Hân', '0900000003', '25 Hai Bà Trưng, TP. Hồ Chí Minh', '115000.00', 'shipping', '2026-11-06 14:39:56'),
(3, 2, 'Nguyễn Minh Anh', '0900000002', '12 Lê Lợi, TP. Hồ Chí Minh', '129000.00', 'completed', '2026-11-06 14:39:56'),
(4, 3, 'Trần Gia Hân', '0900000003', '25 Hai Bà Trưng, TP. Hồ Chí Minh', '33000.00', 'cancelled', '2026-11-06 14:39:56'),
(5, 2, 'Nguyễn Minh Anh', '0900000002', '12 Lê Lợi, TP. Hồ Chí Minh', '79000.00', 'completed', '2026-11-06 14:39:56'),
(6, 4, 'Trịnh Thị Hồng Quyên', '0898944933', '123-888-0000', '19000.00', 'pending', '2026-11-06 15:35:38');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 'Sổ tay Pastel A5', 1, '45000.00'),
(2, 1, 2, 'Sổ lò xo Campus', 1, '39000.00'),
(3, 2, 3, 'Planner tuần Bloom', 1, '68000.00'),
(4, 2, 4, 'Sticky Notes Hoa Nhỏ', 1, '25000.00'),
(5, 2, 7, 'Bút bi Vintage', 1, '22000.00'),
(6, 3, 11, 'Giá đỡ sách Gỗ', 1, '129000.00'),
(7, 4, 6, 'Bút highlight Sorbet', 1, '33000.00'),
(8, 5, 9, 'Hộp bút Linen', 1, '79000.00'),
(9, 6, 12, 'Thước gỗ Mini 20cm', 1, '19000.00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `stock`, `image`, `created_at`) VALUES
(1, 1, 'Sổ tay Pastel A5', 'Sổ ghi chú bìa pastel, giấy kem 80 gsm, 120 trang.', '45000.00', 38, 'images/product-01.svg', '2026-11-06 14:39:56'),
(2, 1, 'Sổ lò xo Campus', 'Sổ lò xo 100 trang, dòng kẻ rõ, dễ ghi chép.', '39000.00', 52, 'images/product-02.svg', '2026-11-06 14:39:56'),
(3, 1, 'Planner tuần Bloom', 'Sổ lên kế hoạch tuần với bố cục linh hoạt.', '68000.00', 24, 'images/product-03.svg', '2026-11-06 14:39:56'),
(4, 1, 'Sticky Notes Hoa Nhỏ', 'Giấy ghi chú nhiều màu, dễ bóc dán.', '25000.00', 75, 'images/product-04.svg', '2026-11-06 14:39:56'),
(5, 2, 'Bút gel Mực Đen 0.5', 'Bút mực gel nét 0.5 mm, viết êm, nhanh khô.', '16000.00', 120, 'images/product-05.svg', '2026-11-06 14:39:56'),
(6, 2, 'Bút highlight Sorbet', 'Bộ bút nhớ dòng tông màu nhẹ mắt.', '33000.00', 48, 'images/product-06.svg', '2026-11-06 14:39:56'),
(7, 2, 'Bút bi Vintage', 'Bút bi thân nhám sang trọng, ngòi 0.7 mm.', '22000.00', 62, 'images/product-07.svg', '2026-11-06 14:39:56'),
(8, 2, 'Bộ bút màu Creative', 'Bộ 12 bút màu cho ghi chú và trang trí.', '85000.00', 30, 'images/product-08.svg', '2026-11-06 14:39:56'),
(9, 3, 'Hộp bút Linen', 'Hộp bút vải canvas khóa kéo bền đẹp.', '79000.00', 18, 'images/product-09.svg', '2026-11-06 14:39:56'),
(10, 3, 'Kẹp giấy Gold Star', 'Bộ kẹp giấy kim loại nhỏ gọn, hình ngôi sao.', '29000.00', 67, 'images/product-10.svg', '2026-11-06 14:39:56'),
(11, 3, 'Giá đỡ sách Gỗ', 'Giá sách mini giúp bàn học ngăn nắp.', '129000.00', 12, 'images/product-11.svg', '2026-11-06 14:39:56'),
(12, 3, 'Thước gỗ Mini 20cm', 'Thước gỗ 20 cm, khắc vạch rõ nét.', '19000.00', 89, 'images/product-12.svg', '2026-11-06 14:39:56');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `phone` varchar(30) NOT NULL DEFAULT '',
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `phone`, `address`, `created_at`) VALUES
(1, 'Quản trị viên', 'admin@quyenshop.test', '$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi', 'admin', '0900000001', 'TP. Hồ Chí Minh', '2026-11-06 14:39:56'),
(2, 'Nguyễn Minh Anh', 'minhanh@example.test', '$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi', 'customer', '0900000002', '12 Lê Lợi, TP. Hồ Chí Minh', '2026-11-06 14:39:56'),
(3, 'Trần Gia Hân', 'giahan@example.test', '$2b$12$vXsUCFJrsnjzocmLQ4eizOIJ6K90bHTDzVbIMRNfTqyL/47D6QIBi', 'customer', '0900000003', '25 Hai Bà Trưng, TP. Hồ Chí Minh', '2026-11-06 14:39:56'),
(4, 'Trịnh Thị Hồng Quyên', 'hongquyen2007.bh@gmail.com', '$2y$12$5ncGhUetuj2yJuPDPjCltufOyDcoUC21ju/yLHbYagJDujJUH3yU2', 'customer', '', NULL, '2026-11-06 15:34:32');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Chỉ mục cho bảng `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_contact_user` (`user_id`);

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_user` (`user_id`);

--
-- Chỉ mục cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_item_order` (`order_id`),
  ADD KEY `fk_item_product` (`product_id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_cat` (`category_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `fk_contact_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_item_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `fk_item_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
